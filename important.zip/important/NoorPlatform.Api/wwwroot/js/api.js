/**
 * منصة نور — طبقة API ومعالجة الأخطاء
 */
(function (global) {
    'use strict';

    const app = () => global.NoorApp;
    const U = () => app().utils;

    function handleApiError(error, options) {
        const opts = options || {};
        const status = error?.status;
        let message = error?.message || 'حدث خطأ غير متوقع';

        if (status === 401) {
            message = 'انتهت الجلسة، يرجى تسجيل الدخول مجدداً';
            if (!opts.skipLogout && typeof global.logout === 'function') global.logout();
        } else if (status === 403) {
            message = 'ليس لديك صلاحية لهذا الإجراء';
        } else if (status === 404) {
            message = error.message || 'العنصر المطلوب غير موجود';
        } else if (status === 500 || status === 502 || status === 503) {
            message = 'الخادم غير متوفر حالياً. حاول لاحقاً';
        } else if (message.includes('Failed to fetch') || message.includes('NetworkError')) {
            message = 'لا يوجد اتصال بالإنترنت أو الخادم غير متاح';
        }

        if (!opts.silent && app().ui?.showToast) {
            app().ui.showToast('❌ ' + message);
        }
        return message;
    }

    async function apiFetch(endpoint, method, body) {
        const state = app().state;
        if (!state.token) {
            const err = new Error('يرجى تسجيل الدخول');
            err.status = 401;
            throw err;
        }

        const options = {
            method: method || 'GET',
            headers: {
                Authorization: 'Bearer ' + state.token,
                'Content-Type': 'application/json'
            }
        };
        if (body && options.method !== 'GET') {
            options.body = JSON.stringify(body);
        }

        let res;
        try {
            res = await fetch(state.apiUrl + endpoint, options);
        } catch {
            const err = new Error('لا يوجد اتصال بالإنترنت أو الخادم غير متاح');
            err.status = 0;
            throw err;
        }

        if (res.status === 401 || res.headers.get('Token-Expired') === 'true') {
            const err = new Error('انتهت الجلسة');
            err.status = 401;
            throw err;
        }

        if (!res.ok) {
            const payload = await res.json().catch(() => ({}));
            const err = new Error(payload.message || 'HTTP ' + res.status);
            err.status = res.status;
            throw err;
        }

        if (res.status === 204) return null;
        const text = await res.text();
        return text ? JSON.parse(text) : null;
    }

    async function apiFetchSafe(endpoint, method, body, options) {
        try {
            return await apiFetch(endpoint, method, body);
        } catch (e) {
            handleApiError(e, options);
            return null;
        }
    }

    const api = { apiFetch, apiFetchSafe, handleApiError };
    app().api = api;

    global.apiFetch = apiFetch;
    global.handleApiError = handleApiError;
})(window);
